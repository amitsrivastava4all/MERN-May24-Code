import { initCount } from "../../../shared/auto-increment.js";
import { getCategory } from "../../category/controller/category-controller.js";
import transactionOperations from "../services/income-expense-crud.js";

// Glue b/w View and Model
// Controller - DOM (View I/O) + Event Handling (View) + Calling Service 

window.addEventListener('load', init);
function init(){
    bindEvents();
    loadCategory();
    printCountTransaction();
}
function bindEvents(){
    document.querySelector('#add').addEventListener('click', addTransaction);
    document.querySelector('#isexpense').addEventListener('change',loadCategory);
    document.querySelector('#delete').disabled = true;
    document.querySelector('#delete').addEventListener('click', deleteForEver);
}

function deleteForEver(){
    
}
function loadCategory(){
    const isChecked = document.querySelector('#isexpense').checked;
    const category = getCategory((isChecked?'expense':'income'));
    const select = document.querySelector('#category');
    select.innerHTML = '';
    category.forEach(c=>{
        const optionTag = document.createElement('option'); // <option></option>
        optionTag.innerText = c;
        select.appendChild(optionTag);
    });
}
const generateId = initCount();
// SRP - 
function addTransaction(){
    const fields = ['category', 'desc','amount', 'mode', 'date'];
    const transactionObject = {}; // Object Literal (Generic - Object Type)
    transactionObject.id = generateId();
    for(let field of fields){
        if(field == 'amount'){
            transactionObject[field] =  parseInt(document.querySelector(`#${field}`).value);
            continue;
        }
        transactionObject[field] =  document.querySelector(`#${field}`).value;
    }
    console.log('Object filled ', transactionObject);
    const transaction = transactionOperations.add(transactionObject);
    printTransaction(transaction);
    printCountTransaction();
    // Generic Object - Convert Specific Object (Specific Operations)
    // read the fields
    // const category = document.querySelector('#category').value;
    // const desc = document.querySelector('#desc').value;
    // const amount = document.querySelector('#amount').value;
    
}
// This function is going to print a single row of transaction
function printTransaction(transaction){
    const tbody = document.querySelector("#transactions-rows");
    const tr = tbody.insertRow();
    for(let key in transaction){
        
        if(key == 'isDeleted' || key =='newlyAdded' || key =='important' || key == 'type'){
            continue; // skip the current iteration
        }
        
        console.log('key is ', key);
        const td = tr.insertCell();
        if(key == 'mode'){
            td.innerText  = modes()[transaction[key]];
        } else
        if(key == 'amount'){
            
            td.innerText = transaction[key].toLocaleString('hi');
        }
        else{
        td.innerText = transaction[key];
        }
    }
    const td = tr.insertCell();
    td.appendChild(createIcon('fa-solid fa-pen-to-square me-2 hand', edit, transaction.id)); // Edit Icon
    // <i class="fa-solid fa-trash"></i>
    td.appendChild(createIcon('fa-solid fa-trash hand', toggleMarkDelete, transaction.id)); // Delete Icon

   
     
}

function toggleMarkDelete(){
    const trashIcon = this;
    const transId = trashIcon.getAttribute('transaction-id');
    console.log('toggleMarkDelete', transId);
    transactionOperations.toggleMark(transId);
    const tr = trashIcon.parentNode.parentNode;
    //tr.className= 'alert alert-danger';
    tr.classList.toggle('table-danger');
    printCountTransaction();
    enableDisable();

}
function enableDisable(){
    document.querySelector('#delete').disabled = transactionOperations.countMarked()==0;
}

function edit(){
    console.log('edit' , this);
}

const modes=()=>["", "Cash", "Credit", "UPI"];
   
function printCountTransaction(){
    document.querySelector('#count-transaction').innerText = transactionOperations.getTransactionsCount();
    document.querySelector('#count-marked').innerText = transactionOperations.countMarked();
    document.querySelector('#count-unmarked').innerText = transactionOperations.countUnMarked();
}

function createIcon(className, fn, transactionId){
    // <i class="fa-solid fa-pen-to-square"></i>
    const icon = document.createElement('i'); // <i>
    icon.className = className;
    icon.setAttribute('transaction-id', transactionId);
    //icon.id = transactionId;
    icon.addEventListener('click', fn);
    return icon;
}