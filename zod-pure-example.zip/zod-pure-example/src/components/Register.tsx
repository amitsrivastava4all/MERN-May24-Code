import { ChangeEvent, FormEvent, useState } from "react";
import { userSchema } from "../schema/user-schema";

type RegisterFields = {
    email:string;
    password:string;
    confirmPassword:string;
    gender:string;
    country:string;
}
export const Register = ()=>{
    const [fields, setFields ] = useState<RegisterFields>({email:'', password:'', confirmPassword:'', gender:'', country:''});
    const [fieldErrors, setFieldErrors] = useState<Record<string , string>>({});
    // take input - own
    // validation - schema validation - zod
    // if valid = data need to store in object - own
    // if valid fail = error handling - own
    const takeInput = (event:ChangeEvent<HTMLInputElement | HTMLSelectElement> )=>{
        const fieldValue = event.target.value;
        const fieldName = event.target.name;
        setFields({...fields, [fieldName]: fieldValue});
    }
    const doSubmit = (event:FormEvent)=>{
        event.preventDefault();
        const result = userSchema.safeParse(fields);
        console.log('Result is ', result);
        if(result.success){
            const myData = result.data;
            setFieldErrors({});
        }
        else{
            // validation fail
            const myFieldErrors:Record<string, string> = {};
            result.error.errors.forEach(errorObject=>myFieldErrors[errorObject.path[0]]=errorObject.message);
            setFieldErrors(myFieldErrors);
        }
    }
    return (<div>
        <h1>Register</h1>
        <form onSubmit={doSubmit}>
            <div>
                <label>Email</label>
                <input name="email" onChange={takeInput} type="text" placeholder="Type Email Here" />
                { fieldErrors.email && <p style = {{color:'red'}}>{fieldErrors.email}</p>}
            </div>
            <div>
                <label>Password</label>
                <input name="password" onChange={takeInput} type="password" placeholder="Type Password Here" />
                { fieldErrors.password && <p style = {{color:'red'}}>{fieldErrors.password}</p>}
            </div>
            <div>
                <label>Password</label>
                <input name="confirmPassword" onChange={takeInput} type="password" placeholder="Type Confirm Password Here" />
                { fieldErrors.confirmPassword && <p style = {{color:'red'}}>{fieldErrors.confirmPassword}</p>}
            </div>
            <div>
                <label>Gender</label>
                <input name="gender" onChange={takeInput} type="radio" value = "M" /> Male
                <input name="gender" onChange={takeInput} type="radio" value = "F" /> Female
                { fieldErrors.gender && <p style = {{color:'red'}}>{fieldErrors.gender}</p>}
            </div>
            <div>
                <label>Country</label>
                <select name="country" onChange={takeInput}>
                    <option  selected defaultValue="" disabled>Select Country</option>
                    {["India", "Srilanka", "China"].map((country, index)=><option key ={index} value = {country}>{country}</option>)}
                </select>
                { fieldErrors.country && <p style = {{color:'red'}}>{fieldErrors.country}</p>}
            </div>
            <div>
                <button>Submit</button>
            </div>
        </form>
    </div>)
}