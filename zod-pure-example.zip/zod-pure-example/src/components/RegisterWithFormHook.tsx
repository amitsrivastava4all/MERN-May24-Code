import { useForm } from "react-hook-form"
import { userSchema, UserSchema } from "../schema/user-schema"
import { zodResolver } from "@hookform/resolvers/zod";



export const RegisterWithFormHook = ()=>{
    
    // take input - register
    // validation - schema validation - zod
    // if valid = handleSubmit
    // if valid fail = formState
   
    const {register, handleSubmit, formState:{errors}} = useForm<UserSchema>({resolver:zodResolver(userSchema)});
    const doSubmit = (user:UserSchema)=>{
        console.log('User is ', user);
    }
    return (<div>
        <h1>Register</h1>
        <form onSubmit={handleSubmit(doSubmit)}>
            <div>
                <label>Email</label>
                <input {...register('email')}  type="text" placeholder="Type Email Here" />
                { errors.email && <p style = {{color:'red'}}>{errors.email.message}</p>}
            </div>
            <div>
                <label>Password</label>
                <input {...register('password')}  type="password" placeholder="Type Password Here" />
                { errors.password && <p style = {{color:'red'}}>{errors.password.message}</p>}
            </div>
            <div>
                <label>Password</label>
                <input {...register('confirmPassword')}   type="password" placeholder="Type Confirm Password Here" />
                { errors.confirmPassword && <p style = {{color:'red'}}>{errors.confirmPassword.message}</p>}
            </div>
            <div>
                <label>Gender</label>
                <input {...register('gender')}    type="radio" value = "M" /> Male
                <input {...register('gender')}   type="radio" value = "F" /> Female
                { errors.gender && <p style = {{color:'red'}}>{errors.gender.message}</p>}
            </div>
            <div>
                <label>Country</label>
                <select {...register('country')}  >
                    <option  selected defaultValue="" disabled>Select Country</option>
                    {["India", "Srilanka", "China"].map((country, index)=><option key ={index} value = {country}>{country}</option>)}
                </select>
                { errors.country && <p style = {{color:'red'}}>{errors.country.message}</p>}
            </div>
            <div>
                <button>Submit</button>
            </div>
        </form>
    </div>)
}