
// import { Register } from './components/Register'
import { RegisterWithFormHook } from './components/RegisterWithFormHook'

function App() {
  return (<RegisterWithFormHook/>)
  // return (<Register/>)
}

export default App
