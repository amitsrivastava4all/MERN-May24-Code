import {z} from 'zod';
export const userSchema = z.object({
    email:z.string().email('Invalid Email'),
    password:z.string()
    .min(8, 'Password is Too Short')
    .max(25, 'Password is Too Large')
    .regex(/[A-Z]/,'Password Must Have one Capital Letter')
    .regex(/[a-z]/,'Password Must Have one small Letter')
    .regex(/\d/,'Password Must Have one Digit ')
    .regex(/[@-_]/,'Password Must Have one Special Letter'),
    confirmPassword:z.string(),
    gender:z.string().min(1,'Gender is Required'),
    country:z.string().nonempty('Country is Required')

}).refine((schemaObject)=>schemaObject.password==schemaObject.confirmPassword,{message:'Password and Confirm Password Must be same',path:['confirmPassword']});
// From Schema I want a Type
export type UserSchema = z.infer<typeof userSchema> 