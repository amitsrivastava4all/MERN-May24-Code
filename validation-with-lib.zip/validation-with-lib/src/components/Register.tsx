import { useForm } from "react-hook-form";

type UserData = {
    email:string;
    password:string;
}
const Register = ()=>{
   const {register, handleSubmit, formState:{errors,isValid,isSubmitting}} =  useForm<UserData>();
   const validSubmission = (data:UserData)=>{
    console.log('Form Submit ', data);
   }
   const validFail = (err:any)=>{
        console.log('Validation Fail ', err);
   }
   // Non Standard
   const pwdValidation = (passwordValue:string)=>{
        if(passwordValue.length<8){
            return "Password it Too Short";
        }
       
   }
    return (<form onSubmit={handleSubmit(validSubmission,validFail)}>
        <label>Email</label>
        <input {...register('email',{required:'Email is Empty', pattern: {value : /^[^\s@]+@[^\s@]+\.[^\s@]+$/ , message:'Invalid Email'}, minLength:{value:5, message:'Min 5 Chars'}})} type="text" placeholder="Type Email Here" />
        {errors && errors.email && errors.email.message && <p>{errors.email.message}</p>}
        <br />
        <label>Password</label>
        <input {...register('password', {validate:pwdValidation}) } type="password" placeholder="Type Password Here" />
        {errors && errors.password && <p>{errors.password.message}</p>}
        <br />
        <button>Register</button>
    </form>)
    
}
export default Register;