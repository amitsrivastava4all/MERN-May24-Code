// User Model contains the Data of User
// Email, Password, NAME
class User{
    constructor(email, password, name){
        this.email = email;
        this.password = password;
        this.name = name;
    }
}
export default User;