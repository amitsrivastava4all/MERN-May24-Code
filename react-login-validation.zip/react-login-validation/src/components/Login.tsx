import { useState } from "react";

type User= {
    email:string;
    password:string;
}

const Login = ()=>{
    
    const [user, setUser] = useState<User>({email:'', password:''});
    //const [error, setError] = useState({errorMessage:'', label:''});
    const [emailerror, setEmailError] = useState({emailErrorMessage:'', label:''});
     const [pwderror, setPwdError] = useState({pwdErrorMessage:'', label:''});
    const takeInput = (event:React.ChangeEvent<HTMLInputElement>, label:string)=>{
        
        const txtValue = event?.target?.value;
        if(label ==='email'){
            user.email = txtValue;
            validateEmail(user.email);
        }
        else{
            user.password = txtValue;
            validatePassword(user.password);
        }
        setUser({...user}); // change state (Immutable)
        console.log('Txt Value is ', txtValue);
    }
    const validateEmail = (email:string)=>{
        if(email.trim().length ==0){
            setEmailError({emailErrorMessage:'Blank Value', label:'Email'});
        }
        else{
            setEmailError({emailErrorMessage:'', label:''});         
        }
    }
    const isBlank = ()=>{

    }
    const onFormSubmit = (event:any)=>{
        validateEmail(user.email);
        validatePassword(user.password);
        event.preventDefault();
        //event.stopPropgation();
    }
    const validatePassword = (password:string)=>{
        if(password.trim().length ==0){
            setPwdError({pwdErrorMessage:'Blank Value', label:'Password'});
        }
        else{
            setPwdError({pwdErrorMessage:'', label:''});         
        }
    }

    return (<form onSubmit={onFormSubmit}>
        <h3>Login Form</h3>
       
        <label>Email</label>
        <input onChange={(event)=>{
            takeInput(event, 'email');
        }} type='text' placeholder='Type Email here'/>
        {emailerror.emailErrorMessage &&<p style={{color:'red'}}>{emailerror.label} {emailerror.emailErrorMessage}</p>}
        <br />
        <label>Password</label>
        <input onChange={(event)=>{
             takeInput(event, 'password');
        }} type='password' placeholder='Type Password here'/>
        
        {pwderror.pwdErrorMessage &&<p style={{color:'red'}}>{pwderror.label} {pwderror.pwdErrorMessage}</p>}
        <br />
        {/* <label>Phone</label>
        <input onChange={(event)=>{
             takeInput(event, 'phone');
        }} type='text' placeholder='Type Phone here'/>
        <br /> */}
        <button >Login</button> &nbsp;
        <button>Reset</button>
    </form>)
}
export default Login;