import { Link, Route, Routes } from "react-router-dom";
import Home from "../components/Home";
import AboutUs from "../components/AboutUs";
import News from "../components/News";
import { Sports } from "../components/Sports";
import { Business } from "../components/Business";

const DashBoard = ()=>{
    return (<div>
        <h1>I am the DashBoard</h1>
        <nav>
            <Link to="/">Home</Link>
            &nbsp;&nbsp;&nbsp;
            {/* <Link to="/about/BrainMentors">About Us</Link> */}
            <Link to="/about?companyname=BrainMentors&location=delhi-ncr">About Us</Link>
            &nbsp;&nbsp;&nbsp;
            <Link to="/news">News</Link>
            
        </nav> 
        <hr />
        <Routes>
             <Route path="/" element={<Home/>}/>  
             {/* <Route path="/about/:companyname" element={<AboutUs/>}/> 
               */}
               <Route path = "/about" element= {<AboutUs/>} />
             <Route path="/news" element={<News/>}>
                <Route path="sports" element={<Sports/>}/>
                <Route path="business" element={<Business/>}/>
                </Route>  
        </Routes>   
    </div>)
}
export default DashBoard;