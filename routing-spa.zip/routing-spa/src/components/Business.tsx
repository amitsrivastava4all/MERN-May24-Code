

export const Business = () => {
  return (
    <div>Business</div>
  )
}
