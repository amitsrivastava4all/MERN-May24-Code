import { useEffect, useState } from "react";
import { useParams, useSearchParams } from "react-router-dom";

const AboutUs = ()=>{
    const params = useParams(); // Path Param
   const [queryparams, setQueryParams] =  useSearchParams();
   console.log('QueryParams ' , queryparams);
   const [paramValue, setParamValue] = useState<string>();
   const printParams = (e:string)=>{
    console.log('Params ', e);
    setParamValue(e);
   }
   useEffect(()=>{
    console.log('Search params');
    let val = ' '
    queryparams.forEach(e=>val+=e+' ');
    printParams(val);
   },[]);
    // Query Param 
    // URL?paramname=value&paramname2=value2 
    return (<div>
        {/* <h1>I am the AboutUs {params.companyname}</h1> */}
        <h1>I am the AboutUs {paramValue} </h1>

    </div>)
}
export default AboutUs;