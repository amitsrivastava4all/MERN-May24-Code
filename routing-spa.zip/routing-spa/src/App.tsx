import { useRef, useState } from 'react'
import DashBoard from './pages/DashBoard'

//import './App.css'
const App = ()=>{
  return (<DashBoard/>)
}
export default App;
// type Customer={
//   id:number;
//   name:string;
//   balance:number;
// }
// function App() {
//   const [customers, setCustomer] = useState<Array<Customer>>([]);
//   const idRef = useRef<HTMLInputElement>(null);
//   const nameRef = useRef<HTMLInputElement>(null);
//   const balanceRef = useRef<HTMLInputElement>(null);
//   const addCustomer = ()=>{
//     const customer:Customer = {
//       id: parseInt(idRef.current?.value!),
//       name:nameRef.current?.value!,
//       balance:parseFloat(balanceRef.current?.value!)
//     }
//     const newCustomers = [...customers, customer];
//     setCustomer(newCustomers);
//   }
//   return (
//     <>
//     <div>
//       <input ref = {idRef} type="text" placeholder='Type Id Here' />
//       <br />
//       <input  ref = {nameRef} type="text" placeholder='Type Name Here' />
//       <br />
//       <input  ref = {balanceRef} type="text" placeholder='Type Balance Here' />
//       <br />
//       <button onClick={addCustomer}>Add Customer</button>
//       <br />
//       <table>
//         <thead>
//         <tr>
//           <th>Id</th>
//           <th>Name</th>
//           <th>Balance</th>
//         </tr>
//         </thead>
//         <tbody>
//           {customers.map(cust=><tr key = {cust.id}>
//             <td>{cust.id}</td>
//             <td>{cust.name}</td>
//             <td>{cust.balance}</td>
//             </tr>)}
//         </tbody>
       
//       </table>
//     </div>
//     </>
//   );
// }

// export default App
