import { getCategory } from "../../category/controller/category-controller.js";

window.addEventListener('load', init);
function init(){
    bindEvents();
    loadCategory();
}
function bindEvents(){
    document.querySelector('#isexpense').addEventListener('change',loadCategory);
}
function loadCategory(){
    const isChecked = document.querySelector('#isexpense').checked;
    const category = getCategory((isChecked?'expense':'income'));
    const select = document.querySelector('#category');
    select.innerHTML = '';
    category.forEach(c=>{
        const optionTag = document.createElement('option'); // <option></option>
        optionTag.innerText = c;
        select.appendChild(optionTag);
    });
}