import { useState } from "react"

export const UsingFirstHook = ()=>{
    console.log('ReRender only UsingFirstHook Component');
    const [counter, setCounter] = useState(0);
    const plus = ()=>{
        //counter++;
        setCounter(counter + 1);
    }
    return (<div>
            <button onClick={plus}>Plus</button>
            <p>Value is {counter}</p>
    </div>)
}