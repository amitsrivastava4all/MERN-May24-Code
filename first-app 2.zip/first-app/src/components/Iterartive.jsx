export const Iterative = ()=>{
    console.log('ReRender only Iterative Component');
    const products = ["Mobiles", "Tablets", "LED TV", "Shirts"];
    return (<div>
        <h4>Iterative Example</h4>
        {products.map((product,index)=><p key = {index}>{product}</p>)}
    </div>)
}