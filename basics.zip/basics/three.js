console.log('Start of the Code'); // Sync Code
setTimeout(function(){ // Async Code (Macro Task)
    console.log('I am the Macro Task ');
}, 0);
Promise.resolve().then(function(){ // Async Code (Micro Task)
    console.log('I am the Micro Task')
})
console.log('End of the Code'); // Sync Code