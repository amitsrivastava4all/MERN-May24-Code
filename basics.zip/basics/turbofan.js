
function add(x, y){
    return x + y;
}
console.log(add(10,20));

// Runtime
console.log(10+20); // Inline Function

// Constant Folding
//const MAX = 10+20*5
// During Runtime
const MAX = 110;
console.log(MAX);

// Dead Code Elimantions
// function show(){
//     console.log('I am the Show...');
// }
// console.log('Code Ends');
// During Runtime
console.log('Code Ends');
