// process - under global object
// Core Modules
// const fs = require('fs');
// const os = require('os');
// const http = require('http');
//console.log(process);
//console.log(global);
// function(exports, require, module, __filename, __dirname)
console.log(arguments);
    var t = 100;
console.log(global.console == console);
console.log(global.setTimeout == setTimeout);
console.log(global.process == process);
console.log(globalThis == global);



