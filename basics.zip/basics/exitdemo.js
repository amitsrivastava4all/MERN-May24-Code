console.log("Start Code ", typeof process);
process.on('beforeExit', function(){
    console.log('I am going to exit the node js ');
})
process.on('uncaughtException', function(err){
    console.log('If Error Present then this will run ', err);
})
//throw new Error('Something went Wrong...');
process.on('exit', function(exitCode){
    console.log('Code is Exit ' ,exitCode );
})
//console.log(process);
console.log(process.cwd());
console.log('Coding is Running');

//console.log(process.memoryUsage());

// node <f.n>.js