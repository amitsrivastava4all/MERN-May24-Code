// Sync (Blocking) , Async (Non Blocking I/O) , Event Driven 
// Internally working of Node JS
const fs = require('fs'); // #include, import
// const MAX = 100;
// MAX++;
console.log('Start the Code'); // Sync Code (Blocking Code)
// __filename - is predefine constant , it give current file path
// fs.readFile(Path, CallbackFn)
fs.readFile(__filename,function(error, content){
    if(error){
        console.log('Error During File Read ', error);
    }
    else{
        console.log('File Content is ', content.toString());
    }
}) ; // Async Code
// Read a file in Async Way (Non Blocking)
console.log('End the Code');