// Service Layer - Logic for CRUD Operations
// export - wrap the things (structure) in an object and then export
// destructure - import {x,y} from 'file'

import Transaction from "../models/transaction.js";

// export default - import x from 'file'
const transactionOperations = {
    // Array of Transactions
    transactions:[], // store Transaction one by one
    add(transObject){
        const transaction = new Transaction();
        for(let key in transObject){
            transaction[key] = transObject[key];
        }
        this.transactions.push(transObject);
        console.log('All Trans ', this.transactions);
    },
    remove(){

    },
    search(){

    },
    sort(){

    },
    update(){

    },
    countTransaction(){

    }
}
export default transactionOperations;
// default - use only one time in a single file.