import { getCategory } from "../../category/controller/category-controller.js";
import transactionOperations from "../services/income-expense-crud.js";

// Glue b/w View and Model
// Controller - DOM (View I/O)

window.addEventListener('load', init);
function init(){
    bindEvents();
    loadCategory();
}
function bindEvents(){
    document.querySelector('#add').addEventListener('click', addTransaction);
    document.querySelector('#isexpense').addEventListener('change',loadCategory);
}
function loadCategory(){
    const isChecked = document.querySelector('#isexpense').checked;
    const category = getCategory((isChecked?'expense':'income'));
    const select = document.querySelector('#category');
    select.innerHTML = '';
    category.forEach(c=>{
        const optionTag = document.createElement('option'); // <option></option>
        optionTag.innerText = c;
        select.appendChild(optionTag);
    });
}

function addTransaction(){
    const fields = ['category', 'desc','amount', 'mode', 'date'];
    const transactionObject = {}; // Object Literal (Generic - Object Type)
    for(let field of fields){
        transactionObject[field] =  document.querySelector(`#${field}`).value;
    }
    console.log('Object filled ', transactionObject);
    transactionOperations.add(transactionObject);
    // Generic Object - Convert Specific Object (Specific Operations)
    // read the fields
    // const category = document.querySelector('#category').value;
    // const desc = document.querySelector('#desc').value;
    // const amount = document.querySelector('#amount').value;
    
}