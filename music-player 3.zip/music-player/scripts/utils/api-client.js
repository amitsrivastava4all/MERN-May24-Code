const getSongs =async (val)=>{
    const URL = `https://itunes.apple.com/search?term=${val}&limit=10`;
    const response = await fetch(URL);
    const object = await response.json();
    const songs = object['results'];
    return songs; // wrap in promise
}
export default getSongs;