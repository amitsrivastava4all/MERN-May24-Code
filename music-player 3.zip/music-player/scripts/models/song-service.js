import getSongs from "../utils/api-client.js";
import SongModel from "./song-model.js";


// Song Related Business Logic


export const songOperations = {
      musicsongs:[],
      getAllSong : async (singerName)=>{
         const songs =  await getSongs(singerName); // itunes model
         // transform itunes data into our model
         const allSongs = songs.map(song=>{
              const mySong = new SongModel(song.trackId,song.trackName,song.collectionName,song.previewUrl, song.artworkUrl100);
              return mySong;
         })
         this.musicsongs = allSongs;
         console.log('All Songs ', allSongs);
         return allSongs;
      }
}