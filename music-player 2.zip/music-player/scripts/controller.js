// Mid Layer b/w View (HTML) and Model (data)
// Glue b/w View and Model

import getSongs from "./api-client.js";
const bindEvents = ()=>{
  const searchButton = document.querySelector('#search-bt');
   searchButton.addEventListener('click', doSearch);
   printSongs();

}
window.addEventListener('load', bindEvents);


const doSearch = ()=>{
  const val = document.querySelector('#search-box').value;
  printSongs(val);
}

// MVC - Design pattern
const printSongs = async (val = "Sonu Nigam")=>{
  const div = document.getElementById('root');
  div.innerHTML = '';
    // 1. Bring the data
    const songs = await getSongs(val);
    console.log('songs ', songs);
    for(var i = 0; i<songs.length ; i++){
        printSong(songs[i]);
    }
}
let previousSong ;
//let currentSong ;
const isPlayingSong = (event)=>{
  
  if(previousSong){
    previousSong.pause();
    previousSong.currentTime = 0;
  }
  
  previousSong =  event.target;
  //console.log('Is Playing Called...', event);
}
const printSong = (currentSong)=>{
  // DOM 
  const cardDiv = document.createElement('div'); // <div></div>
  cardDiv.className = 'card me-2';
  cardDiv.style.width = '18rem';
  const image = document.createElement('img');
  image.src =currentSong.artworkUrl100;
  image.className = 'card-img-top';
  cardDiv.appendChild(image); //<div> <img/> </div>
  const cardBody = document.createElement('div');
  cardBody.className = 'card-body';
  const h5 = document.createElement('h5');
  h5.className = 'card-title';
  h5.innerText = currentSong.trackName;
  cardBody.appendChild(h5);
  cardDiv.appendChild(cardBody);
  const pTag = document.createElement('p');
  pTag.className = 'card-text';
  pTag.innerText= currentSong.collectionName;
  cardBody.appendChild(pTag);
  const audio = document.createElement('audio');
  audio.controls = true;
  audio.addEventListener('play',isPlayingSong);
  audio.src = currentSong.previewUrl;
  audio.type = 'audio/mpeg';
  cardBody.appendChild(audio);
  const div = document.getElementById('root');
  div.appendChild(cardDiv);





  //   const song = `<div class="card me-2" style="width: 18rem;">
  //   <img src="${currentSong.artworkUrl100}" class="card-img-top" alt="...">
  //   <div class="card-body">
  //     <h5 class="card-title">${currentSong.trackName}</h5>
  //     <p class="card-text">${currentSong.collectionName}</p>
  //     <audio controls onplay=${isPlayingSong()}>
  //       <source src="${currentSong.previewUrl}" type="audio/mpeg">
  //     </audio>
  //   </div>
  // </div>`;
  
  // div.innerHTML = div.innerHTML + song;
}
