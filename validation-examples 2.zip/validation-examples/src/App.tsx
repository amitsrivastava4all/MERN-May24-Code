import { AsyncValidation } from "./components/AsyncValidation";
import { DynamicForm } from "./components/DynamicForm";
import Register from "./components/Register";


function App() {
  // return (<Register/>);
  // return (<DynamicForm/>);
  return (<AsyncValidation/>)
}

export default App
