type User = {
    email:string;
    password:string;
    confirmPassword:string;
    gender:string;
    country:string;
    dob:string;
    status:string;
    username:string;
}
export default User;