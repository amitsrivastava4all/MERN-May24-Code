type FirstProps = {
    name:string;
    msg:string;
}
// export const First = (props: FirstProps)=>{
//     return (<h2>{props.msg}  {props.name}</h2>)
// }

// export const First = ({name, msg}: FirstProps)=>{
//     return (<h2>{msg}  {name}</h2>)
// }

export const First = ({name, msg}: {name:string, msg:string})=>{
    return (<h2>{msg}  {name}</h2>)
}