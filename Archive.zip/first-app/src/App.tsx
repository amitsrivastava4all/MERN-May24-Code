import { First } from "./components/First";

const App = ()=>{
  return (<First msg="Hello" name="Amit"/>);
}
export default App;