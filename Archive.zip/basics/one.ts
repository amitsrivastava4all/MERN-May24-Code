var a = 10; // Type Inference / Implicit type
var b = 20;
var c = a + b;
console.log(c);
// a = 10000n;