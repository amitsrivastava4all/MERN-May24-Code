// Sync 
// Async
type Customer = {
    id:number;
    name:string;
    city:string;
}
type Order = {
    customer: Customer;
    oid : number;
    qty : number;
    amount:number;
}
// Sync
function printCustomer(customer:Customer) : Order{
    customer.city = "New Delhi";
    let order: Order = {customer: customer, oid:111, qty:10, amount:1000};
    return order;
}

// Async
function asyncprintCustomer(customer:Customer) : Promise<Order>{
    customer.city = "New Delhi";
    // Future Value 
    // Promise 3 States - Pending , FullFilled, Reject
    const promise = new Promise<Order>((resolve, reject)=>{
        // Async Code
        setTimeout(()=>{
            let order: Order = {customer: customer, oid:111, qty:10, amount:1000};
            resolve(order);
        }, 4000);
       
    })
    
    
    return promise;
}
let c:Customer = {id:1001, name:'Tim', city:'Delhi'};
const pr = asyncprintCustomer(c);
pr.then((order)=>{
    console.log(order);
}).catch(err=>{
    console.log(err);
}).finally(()=>{
    console.log('Always Execute')
})

// function myFn<T>(a:T){

// }
// myFn<string>("Amit");
// myFn<number>(100);

// class A<T>{

// }