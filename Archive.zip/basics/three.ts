function show(x:number=0, y:number=0):number{
    return x + y;
}
var d = show(10,20);
d = show();
function add(x:number, y?:number):void{
    console.log('Add is ', (x+(y??0)));
}
add(10,20);
add(10);

function show2(...a:number[]){

}
show2();
show2(10,20);
show2(10,20,30);
show2(1,2,3,4,5,5,6);
// show2(10,true, "Amit");

// . - member access operator
// obj.id
// ?. - conditionally member access operator
function show3(obj:{id:number, name?:string}):void{
    console.log(obj.id , obj.name?.toUpperCase());

}
show3({id:1001, name:'Ram'});
show3({id:1001});

// Custom Types
type Person = {
    id:number;
    name:string;
}

// function show4():{id:number, name:string}{
//     var obj = {id:1001, name:'Amit'};
//     return obj;
// }

function show4():Person{
    var obj:Person = {id:1001, name:'Amit'};
    return obj;
}