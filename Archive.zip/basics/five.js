// Destructure
// function show(obj:Employee){
//     console.log(obj.name, obj.salary);
// }
function show4(obj) {
    console.log(obj.rollno, obj.name);
}
function show(_a) {
    var name = _a.name, salary = _a.salary;
    console.log(name, salary);
}
function show2(_a) {
    var id = _a.id, salary = _a.salary;
    console.log(id, salary);
}
var e = { id: 1001, name: 'Tim', salary: 9999 };
show(e);
show2({ id: 1000, salary: 88888 });
