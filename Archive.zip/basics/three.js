function show(x, y) {
    if (x === void 0) { x = 0; }
    if (y === void 0) { y = 0; }
    return x + y;
}
var d = show(10, 20);
d = show();
function add(x, y) {
    console.log('Add is ', (x + (y !== null && y !== void 0 ? y : 0)));
}
add(10, 20);
add(10);
function show2() {
    var a = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        a[_i] = arguments[_i];
    }
}
show2();
show2(10, 20);
show2(10, 20, 30);
show2(1, 2, 3, 4, 5, 5, 6);
// show2(10,true, "Amit");
function show3(obj) {
    console.log(obj.id, obj.name);
}
show3({ id: 1001, name: 'Ram' });
show3({ id: 1001 });
