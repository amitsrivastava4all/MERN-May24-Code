// Explicit Types
// Primitive
let h2:number|string|boolean; // Union Types
var h:number|undefined;
h = 100;
h = undefined;
//h= "Abcd";
var a:number;
var a2 = 1000;
a = 100;
var b1:string ;
b1 = "Ram";
var c1:boolean ;
var c2:bigint;
var c3:null;
c3 = null;
var c4:undefined;
c4 = undefined;
var c5:Symbol;

// Reference
var e = [10,20,30, true, "Amit"];
var e2:number[] = [90,1000,200];
var o = {id:1001, name:"ram"};
var o2:{id:number, city:string} = {id:1001, city:'Delhi'};

// Implicit any is bad
let h5;
h5 = 100;
h5 = "Ram";

// any - Compile time checking by pass
let g:any ; // Explicit 
g = 100;
g = "Tom";
g = true;
console.log(g.toUpperCase());

let h6:unknown;
h6 = "Ram";
h6 = 100;
if(typeof h6 ==='string'){
console.log(h6.toUpperCase());
}

let h7:undefined;
h7 = undefined;
//h7 = 1000;