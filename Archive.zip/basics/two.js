// Explicit Types
// Primitive
var h2; // Union Types
var h;
h = 100;
h = undefined;
//h= "Abcd";
var a;
var a2 = 1000;
a = 100;
var b1;
b1 = "Ram";
var c1;
var c2;
var c3;
c3 = null;
var c4;
c4 = undefined;
var c5;
// Reference
var e = [10, 20, 30, true, "Amit"];
var e2 = [90, 1000, 200];
var o = { id: 1001, name: "ram" };
var o2 = { id: 1001, city: 'Delhi' };
// any
var g;
g = 100;
g = "Tom";
g = true;
console.log(g.toUpperCase());
