function show(a:number=0, b:number = 0):void {
//a = "Hello";
var c = a + b;
console.log(c);
}

let t ;
t  =100;
// let a:number = 10;
// a = null;
console.log(show(10,20));

