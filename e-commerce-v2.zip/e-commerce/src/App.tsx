
import { Login } from "@/modules/auth/components/Login";
import { Profile } from "./modules/auth/components/Profile";

const App = ()=><><Login/> <hr/> <Profile/></>
export default App;