import { getData } from "@/shared/services/api-client"

export const getProducts = async ()=>{
    const products = await getData(import.meta.env.PRODUCTS_API_URL);
    console.log('All Products are ', products);
    return products;
}