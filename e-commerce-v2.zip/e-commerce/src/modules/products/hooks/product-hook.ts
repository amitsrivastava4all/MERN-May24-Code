import { getProducts } from "../services/product-service"
import { useProductStore } from "../store/product-store";

export const useProduct= ()=>{
    const addProduct= useProductStore((state=>state.addProduct));
    const getAllProducts= async ()=>{
        const products = await getProducts();
        products.forEach((product:any)=>addProduct(product));
    }
}