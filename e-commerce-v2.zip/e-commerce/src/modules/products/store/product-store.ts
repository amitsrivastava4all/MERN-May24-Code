import { create } from "zustand";
import { Product } from "../models/product-schema";

interface ProductState {
    products:Product[],
    addProduct:(product:any)=>void;
    getAllProducts:()=>void;
    searchProduct:(query:string)=>void;
    sortProduct:(flag:boolean)=>void;

}
export const useProductStore = create<ProductState>((set)=>({
    products:[],
    addProduct:(product:any)=>set((state)=>
    (
        {products:
            [...state.products,
                {
                    id:product.id,
                    name:product.title, 
                    currency:product.currency, 
                    desc: product.description, 
                    price: product.price, 
                    image:product.image
                }]})),
    getAllProducts:()=>set({}),
    searchProduct:(query:string)=>set({}),
    sortProduct:(flag:boolean)=>set({})
}));