// Hook - Talk to FireBase and store state in zustand store.

import { signInWithGoogle } from "../services/auth"
import { useAuthStore } from "../store/user-store";

export const useAuth = ()=>{
    const store = useAuthStore();
    const loginWithGoogle = async ()=>{
        try{
        const user = await signInWithGoogle();
        store.setUser(user);    
        // store this user state in zustand store.
        }
        catch(err){

        }
    }
    return {loginWithGoogle};
}