import { useAuthStore } from "../store/user-store"

export const Profile = ()=>{
    const user = useAuthStore((state)=>state.user);
    console.log('User is ', user);
    return (<>
    <p>Email {user.email}</p>
    <img src = {user.photo} />
    <p>Name {user.name} </p>
    </>)
}