import { Button } from "@/components/ui/button"

import { FaGooglePlus } from "react-icons/fa";
import { useAuth } from "../hooks/auth-hook";

export const Login = () => {
  const {loginWithGoogle} = useAuth();
  const doLogin = async ()=>{
    loginWithGoogle();
        // const user= await signInWithGoogle();
        // console.log(user);
  }  
  return (
    <div>
        <Button onClick={doLogin}> <FaGooglePlus/> Login with Google</Button>
    </div>
  )
}
