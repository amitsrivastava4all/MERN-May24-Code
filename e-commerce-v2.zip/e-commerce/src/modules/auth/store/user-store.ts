// User State Store Here

import { create } from "zustand";

// User Model 
interface User{
    email:string | undefined;
    phone:string;
    photo:string;
    name:string;
}
interface UserModel{
    user:User;
    isAuthenticated:boolean;
    setUser:(user:any)=>void;
}
export const useAuthStore = create<UserModel>((set)=>({
    user:{email:'', phone:'', photo:'', name:''},
    isAuthenticated:false,
   
    setUser:(userObj:any)=>{
        set({user:{email: userObj.email, phone:userObj.phone,photo:userObj.photoURL, name:userObj.displayName }, isAuthenticated:true});
        console.log('User State Set ', userObj.email);
    }
}))
