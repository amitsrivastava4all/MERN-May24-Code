import axios from 'axios';
const axiosObject = axios.create({
    //baseURL:'http://api.shop.com/'
    timeout:5000,
    
});

export const getData = async (URL:string)=>{
    try{
    const response = await axiosObject.get(URL);
    return response.data;
    }
    catch(err){
        throw err;
    }
}
