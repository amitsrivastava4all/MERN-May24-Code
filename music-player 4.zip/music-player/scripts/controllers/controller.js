// Mid Layer b/w View (HTML) and Model (data)
// Glue b/w View and Model


import { songOperations } from "../models/song-service.js";
import { addInPlayList } from "../utils/db/playlist-crud.js";
import { loginWithGoogle } from "../utils/oauth.js";
const bindEvents = ()=>{
  document.querySelector('#login').addEventListener('click', doLogin);
  const searchButton = document.querySelector('#search-bt');
   searchButton.addEventListener('click', doSearch);
   printSongs();

}
window.addEventListener('load', bindEvents);

const doLogin = async ()=>{
  const user = await loginWithGoogle();
  document.querySelector('#userinfo').innerText = 'Email '+user.email + " Welcome Name "+user.displayName;
}

const doSearch = ()=>{
  const val = document.querySelector('#search-box').value;
  printSongs(val);
}
const addOrRemoveToThePlayList = async (currentSong)=>{
  // Add to the FireStore Cloud

  console.log("Add or Remove to the PlayList...");
  /*
  this.id = id;
        this.name = name;
        this.desc = desc;
        this.audiourl = audiourl;
        this.imageurl = imageurl;
        this.isInPlayList = false;
  */
  const doc = await addInPlayList({id : currentSong.id, name: currentSong.name, desc: currentSong.desc, audiourl: currentSong.audiourl, imageurl : currentSong.imageurl,isInPlayList: currentSong.isInPlayList });
  console.log('DOc in Ctrl ', doc);
}
const toggleToPlayList = (currentSong)=>{
  // document - Page
  // Element - <p> <div> <button> (Html elements)
  const button = document.createElement('button'); //<button></button>
  button.innerText = 'Add to PlayList';
  button.addEventListener('click', ()=>{
    addOrRemoveToThePlayList(currentSong);
  });
  button.className = 'btn btn-success';
  return button;
}
/*
Controller will call --> Service --> Api Client call (Itunes )
*/
// MVC - Design pattern
const printSongs = async (val = "Sonu Nigam")=>{
  const div = document.getElementById('root');
  div.innerHTML = '';
    // 1. Bring the data with the help of service
    //const songs = await getSongs(val);
    const songs = await songOperations.getAllSong(val);
    console.log('songs ', songs);
    for(var i = 0; i<songs.length ; i++){
        printSong(songs[i]);
    }
}
let previousSong ;
//let currentSong ;
const isPlayingSong = (event)=>{
  
  if(previousSong){
    previousSong.pause();
    previousSong.currentTime = 0;
  }
  
  previousSong =  event.target;
  //console.log('Is Playing Called...', event);
}
const printSong = (currentSong)=>{
  // DOM 
  const cardDiv = document.createElement('div'); // <div></div>
  cardDiv.className = 'card me-2';
  cardDiv.style.width = '18rem';
  const image = document.createElement('img');
  image.src =currentSong.imageurl;
  image.className = 'card-img-top';
  cardDiv.appendChild(image); //<div> <img/> </div>
  const cardBody = document.createElement('div');
  cardBody.className = 'card-body';
  const h5 = document.createElement('h5');
  h5.className = 'card-title';
  h5.innerText = currentSong.name;
  cardBody.appendChild(h5);
  cardDiv.appendChild(cardBody);
  const pTag = document.createElement('p');
  pTag.className = 'card-text';
  pTag.innerText= currentSong.desc;
  cardBody.appendChild(pTag);
  const audio = document.createElement('audio');// <audio>
  audio.controls = true; // <audio controls>
  audio.addEventListener('play',isPlayingSong); // <audio controls onplay="isPlayingSong()">
  audio.src = currentSong.audiourl;
  audio.type = 'audio/mpeg';
  cardBody.appendChild(audio);
  cardBody.appendChild(toggleToPlayList(currentSong));
  const div = document.getElementById('root');
  div.appendChild(cardDiv);





  //   const song = `<div class="card me-2" style="width: 18rem;">
  //   <img src="${currentSong.artworkUrl100}" class="card-img-top" alt="...">
  //   <div class="card-body">
  //     <h5 class="card-title">${currentSong.trackName}</h5>
  //     <p class="card-text">${currentSong.collectionName}</p>
  //     <audio controls onplay=${isPlayingSong()}>
  //       <source src="${currentSong.previewUrl}" type="audio/mpeg">
  //     </audio>
  //   </div>
  // </div>`;
  
  // div.innerHTML = div.innerHTML + song;
}
