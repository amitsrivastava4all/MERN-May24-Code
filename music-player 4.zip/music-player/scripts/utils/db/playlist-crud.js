import { collection, addDoc } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js"; 
import { db } from "../firebase-config.js";
export const addInPlayList = async (song)=>{
 

// Add a new document with a generated id.
const docRef = await addDoc(collection(db, "playlists"), song);
console.log("Document written with ID: ", docRef);
}