// FireBase config file - contains the linkage configuration with firebase
// this file content is provide by firebase
  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-analytics.js";
  import { getFirestore } from 'https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js'
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
    apiKey: "AIzaSyAgllhdZBkcgmuo3KXgakFxr-QWRc248P4",
    authDomain: "musicapp-c3b4e.firebaseapp.com",
    projectId: "musicapp-c3b4e",
    storageBucket: "musicapp-c3b4e.appspot.com",
    messagingSenderId: "520169664373",
    appId: "1:520169664373:web:8d68d6f8afe49a1166ad3c",
    measurementId: "G-23FNJ6CSCR"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);
  export const db = getFirestore(app);
