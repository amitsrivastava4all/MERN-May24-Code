import getSongs from "../utils/api-client.js";
import SongModel from "./song-model.js";


// Song Related Business Logic


export const songOperations = {
      musicsongs:[],
      /*
         Service will call BackEnd Api using api-client.js
         Convert data into frontend model
      */
      getAllSong : async function (singerName){
         const songs =  await getSongs(singerName); // itunes model
            console.log('Before Model ', songs);
         // transform itunes data into our model
         const allSongs = songs.map(song=>{
              const mySong = new SongModel(song.trackId,song.trackName,song.collectionName,song.previewUrl, song.artworkUrl100);
              return mySong;
         });
         console.log('Aftet Model All Songs are ', allSongs);
         this.musicsongs = allSongs;
         console.log('All Songs ', this.musicsongs);
         return allSongs;
      }
}