const getSongs =async ()=>{
    const URL = 'https://itunes.apple.com/search?term=sonu nigam&limit=10';
    const response = await fetch(URL);
    const object = await response.json();
    const songs = object['results'];
    return songs; // wrap in promise
}
export default getSongs;