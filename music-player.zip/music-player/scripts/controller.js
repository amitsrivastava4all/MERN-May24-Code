// Mid Layer b/w View (HTML) and Model (data)
// Glue b/w View and Model

import getSongs from "./api-client.js";

// MVC - Design pattern
const printSongs = async ()=>{
    // 1. Bring the data
    const songs = await getSongs();
    console.log('songs ', songs);
    for(var i = 0; i<songs.length ; i++){
        printSong(songs[i]);
    }
}
const printSong = (currentSong)=>{
    const song = `<div class="card me-2" style="width: 18rem;">
    <img src="${currentSong.artworkUrl100}" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">${currentSong.trackName}</h5>
      <p class="card-text">${currentSong.collectionName}</p>
      <audio controls>
        <source src="${currentSong.previewUrl}" type="audio/mpeg">
      </audio>
    </div>
  </div>`;
  const div = document.getElementById('root');
  div.innerHTML = div.innerHTML + song;
}
printSongs();