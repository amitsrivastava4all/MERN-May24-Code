

// Back End API Calls / WebService/ WEB API 
export type Song = {
    trackName:string;
    collectionName:string;
    previewUrl:string;
    artworkUrl100:string;

}
const getAllSongs = async ():Promise<Song[]> =>{
    console.log('URL is ', import.meta.env.VITE_ITUNES_URL);
    const response = await fetch(import.meta.env.VITE_ITUNES_URL); // Env URL 
    console.log(response);
    // if(response.status == 200){}
    const data = await response.json();  // JSON parse Object
    const songs:Song[] = data.results; // any convert Song Type
    // Song Traverse and pick the required fields
    const allSongs:Song[] = songs.map(s=>{
        // Destructure the required fields
        const {trackName , collectionName, previewUrl, artworkUrl100}:Song = s;
        // return one by one object - store in a new array (allSongs array)
        return {trackName, collectionName, previewUrl, artworkUrl100};    
    });
    return allSongs;
}
export default getAllSongs;