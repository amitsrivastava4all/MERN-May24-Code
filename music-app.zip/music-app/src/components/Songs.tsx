import SongCard from "./SongCard";


const Songs = () => {
  return (
    <div className="row">
        
        <SongCard/>
       
    </div>
  )
}
export default Songs;
