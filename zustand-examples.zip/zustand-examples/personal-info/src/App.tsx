import { Button } from "@/components/ui/button"
import { Input } from "./components/ui/input"

const App = ()=>{
  return (
  <>
  <Input/>
  <Button>Hello</Button>
  </>)
}
export default App;