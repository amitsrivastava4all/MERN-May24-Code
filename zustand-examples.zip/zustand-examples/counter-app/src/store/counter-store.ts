import { create } from "zustand";

// interface Person{
//   name:string;
//   email:string;
//   phone:string;
//   city:string;
// }


// interface PersonType {
//   person:Person[];
//   add:()=>void;
//   view:()=>void;
// }
// Step - 1 Store Skeleton
interface CounterType {
    counter:number;
    plus:()=>void;
    minus:()=>void;
}
// Step - 2 Create Store (Here the State is going to store)

export const useCounterStore = create<CounterType>((set)=>({
  counter:0,
  plus:()=>set((state)=>({counter:state.counter+1})),
  minus:()=>set((state)=>({counter: state.counter-1}))
}));

