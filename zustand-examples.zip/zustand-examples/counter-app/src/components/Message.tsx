import { useCounterStore } from "../store/counter-store"


export const Message = () => {
    const counter = useCounterStore(state=>state.counter);
  return (
    <div>
        <h1>Count is {counter}</h1>
    </div>
  )
}
