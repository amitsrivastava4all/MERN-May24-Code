import { useCounterStore } from "../store/counter-store"

type ButtonProps= {
    val:string;
}
export const Button = ({val}:ButtonProps) => {
    // store Hook
    const plus = useCounterStore((state)=>state.plus);
    const minus = useCounterStore((state)=>state.minus);
  return (
    <button onClick={val=='+'?plus:minus}>{val}</button>
  )
}

