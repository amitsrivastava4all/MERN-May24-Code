import { Button } from "../components/Button"
import { Message } from "../components/Message"


export const CounterApp = () => {
  return (
    <div>
        <Message/>
        <Button val="+"/>
        &nbsp;
        <Button val="-"/>
    </div>
  )
}
