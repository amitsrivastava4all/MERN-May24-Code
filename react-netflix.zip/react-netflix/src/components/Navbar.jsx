import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <>
      <div className="fixed h-20 w-screen bg-transparent text-black flex justify-between items-center">
        <div className="">
          <ul className="flex items-center space-x-5 font-bold">
            <li>
              <img
                height={80}
                width={100}
                src="https://cdn1.iconfinder.com/data/icons/logos-brands-in-colors/7500/Netflix_Logo_RGB-512.png"
                alt="Failed To load Logo"
              />
            </li>
            <li>
              <Link className=" hover:text-blue-500" to="#">
                Home
              </Link>
            </li>
            <li>
              <Link to="#">Tv Shows</Link>
            </li>
            <li>
              <Link to="#">Movies</Link>
            </li>
            <li>
              <Link to="#">New & Popular</Link>
            </li>
            <li>
              <Link to="#">My List</Link>
            </li>
            <li>
              <Link to="#">Browse By Language</Link>
            </li>
          </ul>
        </div>
        <div className="flex justify-center items-center px-3">
          <div className="space-x-3 border-black border-2 rounded-lg px-3 mx-3 py-1">
            <input type="text" className="bg-white text-black outline-none " />
            <i className="fa-solid fa-magnifying-glass text-black"></i>
          </div>
          <div className="text-white rounded-lg flex justify-center items-center h-8 w-8 bg-green-700">
            H
          </div>
        </div>
      </div>
    </>
  );
};

export default Navbar;
