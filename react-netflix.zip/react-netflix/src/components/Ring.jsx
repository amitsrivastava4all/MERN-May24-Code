import "./Ring.css";

const Ring = () => {
  return (
    <div className="h-screen  flex justify-center items-center">
      <div className="myring border-4 border-x-red h-40 w-40 bg-white"></div>
    </div>
  );
};

export default Ring;
