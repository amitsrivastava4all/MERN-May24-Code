import Navbar from "./components/Navbar";
// import Ring from "./components/Ring";
import "./App.css";

function App() {
  return (
    <>
      {/*<Navbar />*/}
      <Navbar />
    </>
  );
}

export default App;
