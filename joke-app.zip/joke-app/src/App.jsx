import { useState } from "react"
import { Button } from "./components/Button"
import { Message } from "./components/Message"
import { getJoke } from "./services/api-client"

// Root Component
const App = ()=>{
 // let joke = {setup:'', punchline:''}; 
  // Immutable
  const [joke, setJoke] =  useState({setup:'', punchline:''});
  const getJokesData = async ()=>{
    // Api Call
    //joke = await getJoke(); // Never use this way mutable
    setJoke( await getJoke()); // state change - immutable way
    console.log('Joke is ', joke);
  }
  return (<>
      <Message joke = {joke}/>
      <Button fn = {getJokesData}/>
    </>)
}
export default App;