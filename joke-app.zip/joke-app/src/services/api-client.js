// It makes an API Call
const URL = 'https://official-joke-api.appspot.com/random_joke';
export async function getJoke(){
    const response = await fetch(URL);
    // Parsing
    const obj = await response.json(); // Deserialization
    return obj; // object wrap in promise
}