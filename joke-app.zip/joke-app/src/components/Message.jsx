export const Message = ({joke})=>{
    return (<>
            <h2>{joke.setup} </h2>
             <h3>{joke.punchline}</h3>
    </>
    )
}