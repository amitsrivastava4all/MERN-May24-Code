export const Button = ({fn})=>{
    return (<button onClick={fn}>Get Joke</button>)
}