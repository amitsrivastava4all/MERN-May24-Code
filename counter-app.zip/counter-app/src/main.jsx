import {createRoot} from 'react-dom/client';
import App from './App';
// main.jsx file - html file connect with Root Component
const div = document.querySelector('#root'); // DOM Access (Source)
const root = createRoot(div); // DOM Provide Root
root.render(<App/>); // Sync VDOM - DOM