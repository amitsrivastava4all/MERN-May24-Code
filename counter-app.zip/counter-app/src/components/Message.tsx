type MessagePropType = {
    msg:string;
    val?:number;
}
// const Message = (props:MessagePropType)=>{
//     return (<h2>{props.msg}</h2>)
// }
const Message = ({msg, val}:MessagePropType)=>{
    return (<h2>{msg} {val}</h2>)
}
export default Message;