export const Button = (props)=>{
    console.log('Button Render');
    // const myStyle = {
    //     backgroundColor: obj.color,
    //     color:'white',
    //     fontSize:'40px'
    // };
    return (<button onClick={props.fn} style={{
        backgroundColor: props.color,
        color:'white',
        fontSize:'40px'
    }}>{props.value}</button>)
}