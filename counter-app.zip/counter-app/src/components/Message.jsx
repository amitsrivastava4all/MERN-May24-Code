export const Message = ({msg, color, value=""})=>{
    console.log('Message Render');
    return (<h1 style = {{color:color}}>{msg} {value}</h1>)
}