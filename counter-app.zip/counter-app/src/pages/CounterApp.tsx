import { useState } from "react"
import Button from "../components/Button"
import Message from "../components/Message"

const CounterApp = ()=>{
    const [counter, setCounter]= useState<number>(0);
   // let counter = 0;
    const plus = ()=>{
        // State Update (ASYNC) - Non Blocking
        setCounter(counter + 1); // Immutable
        //counter++; // Mutable
        console.log('Plus ', counter);
    }
    const minus = ()=>{
       // counter--;
       setCounter(counter - 1); // Immutable
        console.log('Minus ', counter);
    }
    return (<div>
        <Message msg="Counter App"/>
        <Message msg="Count is " val = {counter}/>
        <Button fn = {plus} label="+"/> &nbsp;
        <Button fn = {minus} label="-"/>
    </div>)
}
export default CounterApp;