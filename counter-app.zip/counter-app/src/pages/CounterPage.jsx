import { useState } from "react"
import { Button } from "../components/Button"
import { Message } from "../components/Message"

export const CounterPage = ()=>{
    console.log('Counter Page Render');
   //(Additional Functionality) Hook - function
   // hooks all start with use word
   const [counter, setCounter] = useState(0);

    const plus = ()=>{
        setCounter(counter + 1);
        //counter++;
        //console.log('Plus call ', counter);
    }
    const minus = ()=>{
        setCounter(counter - 1);
       // counter--;
        //console.log('Minus call ', counter);
    }
    return (<div>
        <Message msg = "Counter App" color="blue"/>
        <Message msg = "Count Value is " color="green" value = {counter}/>
        <Button value="+" color="green" fn = {plus}/> &nbsp;
        <Button value="-" color="red" fn = {minus}/>
    </div>)
}