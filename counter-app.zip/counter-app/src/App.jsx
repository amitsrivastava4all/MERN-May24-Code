// Root Component / First Component
// Component - It is a function having JSX 

import { CounterPage } from "./pages/CounterPage";

// Component - It is a small View of your page
const App = ()=>{
  console.log('APP Render');
  return (<CounterPage/>
  )
}
export default App;