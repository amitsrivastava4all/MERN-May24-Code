import React from 'react'
import { UserPage } from './components/UserPage';

 const App = () => {
  return (
      <UserPage/>
  )
}
export default App;
