import React from 'react'

export const DashBoard = () => {
  return (
    <div>DashBoard</div>
  )
}
