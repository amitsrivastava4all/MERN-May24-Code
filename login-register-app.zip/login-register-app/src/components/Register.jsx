import React from 'react'
import { TextBox } from '../shared/widgets/TextBox'
import { PasswordField } from '../shared/widgets/PasswordField'
import { Button } from '../shared/widgets/Button'

export const Register = () => {
  const takeInput = (event)=>{
    console.log('Take Input call ', event.target.value);
  }
  return (
    <>
    <TextBox fn = {takeInput} lbl="Userid" watermark="Type Userid Here"/>
   <PasswordField/>
    <TextBox fn= {takeInput} lbl="Name" watermark="Type Name Here"/>
    <TextBox fn = {takeInput} lbl="Phone" watermark="Type Phone Here"/>
<br />
    <div className='row'>
   <Button lbl = "Register" css="success"/>
   <Button lbl="Reset" css="danger"/>
   </div>
</>
  )
}
