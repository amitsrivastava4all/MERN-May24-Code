import React from 'react'

export const Button = ({lbl, css}) => {
  const cssClass = `btn btn-${css}`;  
  return (
    <div className='col-2'>
         <button className={cssClass}>{lbl}</button> 
    </div>
  )
}
