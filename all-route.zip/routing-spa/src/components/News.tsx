import { Link, Outlet } from "react-router-dom";


 const News = () => {
  return (
    <div>
        <h1>News</h1>
        <Link to="sports">Sports News</Link> &nbsp;
        &nbsp;
        <Link to="business">Business News</Link>
        <hr />
        <Outlet/>
    </div>
    
  )
}
export default News;
