import { useEffect, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";

const AboutUs = ()=>{
    const navigate = useNavigate();
    const params = useParams(); // Path Param
   const [queryparams, setQueryParams] =  useSearchParams(); // Query Params
   console.log('QueryParams ' , queryparams);
   const [paramValue, setParamValue] = useState<string>();
   const printParams = (e:string)=>{
    console.log('Params ', e);
    setParamValue(e);
   }
   const move = ()=>{
    navigate("/", {state :{name:'Amit', city:'Delhi'}} );
   }
   useEffect(()=>{
    console.log('Search params');
    let val = ' '
    queryparams.forEach(e=>val+=e+' ');
    printParams(val);
   },[]);
    // Query Param 
    // URL?paramname=value&paramname2=value2 
    return (<div>
        {/* <h1>I am the AboutUs {params.companyname} {params.location}</h1> */}
        <h1>I am the AboutUs {paramValue} </h1>
        <br />
        <button onClick={move}>Move to Home</button>

    </div>)
}
export default AboutUs;