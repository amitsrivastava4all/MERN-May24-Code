

export const NotFound = () => {
  return (
   <h1>OOPS U Type Something Else...</h1>
  )
}
