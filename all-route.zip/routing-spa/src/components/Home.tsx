import { useLocation } from "react-router-dom";

const Home = ()=>{
    const location= useLocation();
    const state = location.state ;
    console.log('Location State ', state);
    return (<div>
        <h1>I am the Home {location.state?.name} {location.state?.city}</h1>

    </div>)
}
export default Home;