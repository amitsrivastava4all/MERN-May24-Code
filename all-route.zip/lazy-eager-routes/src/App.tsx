import { Link, Route, Routes } from "react-router-dom";
import { Home } from "./components/Home";
import { lazy, Suspense } from "react";
import ErrorBoundary from "./components/ErrorBoundary";



function App() {
  const About = lazy(()=>import('./components/About'));
  const News = lazy(()=>import('./components/News'));
  return (<>
   
    <Link to="/">Home</Link> &nbsp;
    <Link to="/about">About</Link>  &nbsp;
    <Link to="/news">News</Link>
    <Suspense fallback = {<h3>Loading...</h3>}>
    <ErrorBoundary>
    <Routes>
        <Route path="/" element = {<Home/>}/>
        <Route path="/about" element = {<Suspense fallback={<p>Loading...</p>}><About/></Suspense>}/>
        <Route path="/news" element = {<Suspense fallback={<p>Loading***** </p>}><News/></Suspense>}/>
    </Routes>
    </ErrorBoundary>
    </Suspense>
  </>);
}

export default App
