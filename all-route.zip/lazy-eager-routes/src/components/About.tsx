

 const About = () => {
   throw new Error('Something went Wrong....');
    return (
      <h1>About</h1>
      
    )
  }
  export default About;
  