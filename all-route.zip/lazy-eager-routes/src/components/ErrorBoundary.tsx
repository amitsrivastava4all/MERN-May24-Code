import { Component, ErrorInfo, ReactNode } from "react";
interface Props{
    children : React.ReactNode;
}
interface State{
    hasError: boolean;
}
class ErrorBoundary extends Component<Props, State>{
    constructor(props:Props){
        super(props);
        this.state = { hasError: false}; // No error 
    }
    static getDerivedStateFromError(error:Error):State{
        console.log('getDerivedStateFromError ', error);
        return {hasError:true};
    }
    componentDidCatch(error: Error, errorInfo: ErrorInfo): void {
        console.log('Error Catch By ErrorBoundary....', error, errorInfo);
    }
    render(): ReactNode {
        console.log('Render Again...', this.state)
        if(this.state.hasError){
            return <h2>OOPS Something went Wrong...</h2>
        }
        else{
            return this.props.children;
        }
    }
}
export default ErrorBoundary;