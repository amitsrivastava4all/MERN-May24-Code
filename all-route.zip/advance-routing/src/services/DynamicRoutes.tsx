import { useRoutes } from "react-router-dom";
import { About } from "../components/About"
import { Home } from "../components/Home"
import { Orders } from "../components/Orders";
import { PrivateRoute } from "../components/PrivateRoute";
import { Profile } from "../components/Profile";

export const DyamicRoutes = ()=>{
    // fetch(URL)
    const routes = [
        // Public Routes
        {path:'/', element: <Home/>},
        {path:'/about', element: <About/>},
        // Private Routes
        {path:'/profile' , element: <PrivateRoute><Profile/></PrivateRoute>},
        {path:'/orders' , element: <PrivateRoute><Orders/></PrivateRoute>}
    ];
    const routing = useRoutes(routes);
    return routing;
    
     {/* <Routes>
    
        <Route path='/' element={<Home/>}/>
        <Route path='/about' element={<About/>}/>
       
        <Route path = '/profile'  element= {<PrivateRoute><Profile/></PrivateRoute>}/>
        <Route path = '/orders'  element= {<PrivateRoute><Orders/></PrivateRoute>}/>
    </Routes> */}
    

}