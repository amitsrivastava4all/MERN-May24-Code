

export const Profile = () => {
  return (
    <h1>User Profile</h1>
  )
}
