import { Navigate } from "react-router-dom";

// const isAuthenticatedCheck = ()=>{
//     const token = localStorage.getItem('token');
//     return token!=null;
// }
export const PrivateRoute = ({children}:{children:JSX.Element})=>{
    //const isAuthenticated = isAuthenticatedCheck(); // BackEnd API
    const isAuthenticated = false;
    return isAuthenticated ? children :<Navigate to="/"/>
}

