
import { Link, Route, Routes } from 'react-router-dom'

import { Home } from './components/Home'
import { About } from './components/About'
import { Profile } from './components/Profile'
import { PrivateRoute } from './components/PrivateRoute'
import { Orders } from './components/Orders'
import { DyamicRoutes } from './services/DynamicRoutes'

function App() {
  

  return (
    <>
    <Link to="/">Home</Link>
    &nbsp;
    <Link to="/about">About</Link>
    &nbsp;
    <Link to="/profile">Profile</Link>
    &nbsp;
    <Link to="/orders">Orders</Link>
    <br />
    <hr />
    <DyamicRoutes/>
      {/* <Routes>
       
          <Route path='/' element={<Home/>}/>
          <Route path='/about' element={<About/>}/>
         
          <Route path = '/profile'  element= {<PrivateRoute><Profile/></PrivateRoute>}/>
          <Route path = '/orders'  element= {<PrivateRoute><Orders/></PrivateRoute>}/>
      </Routes> */}
    </>
  )
}

export default App
