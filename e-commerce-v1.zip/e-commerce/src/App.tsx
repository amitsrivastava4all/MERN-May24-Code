
import { Login } from "@/modules/auth/components/Login";

const App = ()=><Login/>
export default App;