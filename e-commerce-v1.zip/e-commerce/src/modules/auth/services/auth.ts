import { firebaseConfig } from "@/shared/config/firebase";
import { initializeApp } from "firebase/app";
import { getAuth, signInWithPopup, GoogleAuthProvider } from "firebase/auth";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const googleAuthProvider = new GoogleAuthProvider();
export const signInWithGoogle = async ()=>{
    try{
    const result = await signInWithPopup(auth, googleAuthProvider);
    const token = await result.user.getIdToken();
    console.log('Token is ', token);
    localStorage.setItem('access-token', token);
    console.log('User Info is ', result.user);
    return result.user;
    }
    catch(err:any){
        return err;
    }
}