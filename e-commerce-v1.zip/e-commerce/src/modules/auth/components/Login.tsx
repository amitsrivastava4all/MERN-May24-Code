import { Button } from "@/components/ui/button"
import { signInWithGoogle } from "../services/auth"
import { FaGooglePlus } from "react-icons/fa";

export const Login = () => {
  const doLogin = async ()=>{
        const user= await signInWithGoogle();
        console.log(user);
  }  
  return (
    <div>
        <Button onClick={doLogin}> <FaGooglePlus/> Login with Google</Button>
    </div>
  )
}
