// this is first component (Root Component)
// Component - Arrow Function with JSX
import React from 'react';
import { Iterative } from './components/Iterartive';
import { UsingFirstHook } from './components/UsingFirstHook';
const App = ()=>{
  console.log('ReRender only App Component');
  const address = 'New Delhi';
  const author = 'Shyam';
  const isLoggedIn = true;
 // return (<h1>Hello React JS</h1>)
 // React.createElement - Create Element 
 const myStyle = {backgroundColor:'cyan', color:'red'};
  return (<div style ={myStyle}>
    <h1>Hello React JS {author}</h1> 
    <h2>Hi React JS</h2>
    <h3> Your Name is {author} and City is {address}</h3>
    {isLoggedIn?<button>Logout</button>:<p>You Need to Login First</p>}
    <Iterative/>
    <UsingFirstHook/>
    </div>);
//  return React.createElement('div',{style:{backgroundColor:'cyan'}}, React.createElement('h1', null,'Hi React JS')
//  , React.createElement('h2', null, 'Hello React JS'));

}
export default App;