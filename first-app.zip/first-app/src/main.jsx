// Sync B/w VDOM and DOM
// DOM Build document.createElement
// document.getElementById - DOM Element Access
import  {createRoot} from 'react-dom/client';
import App from './App';
const div = document.getElementById('root'); // dom
const root = createRoot(div); // dom root
root.render(<App/>) ; // root render App (VDOM convert DOM)
// call App component (Function) , function return JSX (VDOM) --> DOM