type User = {
    email:string;
    password:string;
    confirmPassword:string;
    gender:string;
    country:string;
    dob:string;
    status:string;
}
export default User;