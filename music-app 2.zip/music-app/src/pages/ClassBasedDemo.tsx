// // React 16.8 onwards Hooks
// // Functional Component - Arrow Function + UI Logic / Design
// // state, life cycle - additional features (Hooks) (Predefine) (Custom)
// // Hooks - Logic
// // const MyComp = ()=>{
// //     return (<h1>Hello React JS</h1>)
// // }

// import { Component } from "react";

// // Class Based Component
// class ClassBasedComponent extends Component{
//     x:number;
//     y:number;
//     constructor(props:any){
        
//         super(props);  // Parent Constructor call
//         this.x = 10;
//         this.y = 20;
//     }
//     componentDidMount(): void {
        
//         // Logic
//     }
//     myLogic(){
//         console.log('This is ', this)
//         console.log(this.x + this.y);
//     }
//     render(){
//         return (<>
//          <h1>Hello React </h1>
//          <button onClick={this.myLogic.bind(this)}>Plus</button>
//         </>)
//     }

// }