/** @type {import('tailwindcss').Config} */
export default {
  content: ["./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        customColor: "#42f58d",

        themeColor: {
          100: "#42f58d",
          200: "#42f58d",
          300: "#42f58d",
          400: "#42f58d",
          500: "#42f58d",
          600: "#42f58d",
        },
      },
    },
  },
  plugins: [],
};
