import Grid from "./components/Grid";

function App() {
  return <Grid />;
}

export default App;
