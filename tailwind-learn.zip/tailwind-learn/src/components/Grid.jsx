const Grid = () => {
  return (
    <div className="grid md:grid-cols-2 gap-4 sm:grid-cols-1">
      <div className="bg-indigo-500">1</div>
      <div className="bg-indigo-500">2</div>
      <div className="bg-indigo-500">3</div>
      <div className="bg-indigo-500">4</div>
      <div className="bg-indigo-500">5 </div>
      <div className="bg-indigo-500">6</div>
      <div className="bg-indigo-500">7 </div>
      <div className="bg-indigo-500">8 </div>
      <div className="bg-indigo-500">9 </div>
    </div>
  );
};

export default Grid;
